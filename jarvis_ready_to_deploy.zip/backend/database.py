import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "jarvis.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS error_log
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT, error_type TEXT, message TEXT, stack_trace TEXT, resolved INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)''')
    c.execute('''CREATE TABLE IF NOT EXISTS evolution_log
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, change_id INTEGER, file_path TEXT, description TEXT, old_text TEXT, new_text TEXT, backup_path TEXT, status TEXT DEFAULT 'applied', created_at DATETIME DEFAULT CURRENT_TIMESTAMP)''')
    c.execute('''CREATE TABLE IF NOT EXISTS file_backups
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, evolution_id INTEGER, file_path TEXT, backup_path TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)''')
    c.execute('''CREATE TABLE IF NOT EXISTS config
                 (key TEXT PRIMARY KEY, value TEXT)''')
    # Default configs
    defaults = {
        'user_name': 'sir',
        'greeting_style': 'formal',
        'voice_rate': '1.05',
        'voice_pitch': '0.92',
        'challenger_intensity': 'high',
        'persona_notes': 'Dry wit, technically precise, respects intellect, never sycophantic.',
        'auto_fix_config': 'true',
        'auto_fix_code': 'true',
        'proactive_maintenance': 'true',
        'voice_autonomy': 'high'
    }
    for k, v in defaults.items():
        c.execute("INSERT OR IGNORE INTO config (key, value) VALUES (?, ?)", (k, v))
        
    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
