import json
import os
from dotenv import load_dotenv
from security.log_redact import redact
from security.injection_gate import gate

# Load keys if .env exists
load_dotenv(os.path.join(os.path.dirname(__file__), '..', '.env'))

# Fix import depending on where it's called from
try:
    from .memory_manager import MemoryManager
    from .skills.vision import analyze_screen_frame
except ImportError:
    from memory_manager import MemoryManager
    import sys
    sys.path.append(os.path.dirname(__file__))
    from skills.vision import analyze_screen_frame

class JarvisBrain:
    def __init__(self):
        self.version = "v2"
        self.memory_manager = MemoryManager()
        
        # Personality Persistence Step 1 & 3: The Recency Voice Cue
        self._voice_cue = (
            "\n\n[Voice check — agent mode, not generic assistant mode. Answer first; one "
            "or two sentences unless detail was asked. EARN THE SMIRK: dry "
            "observation, needle, undercut, deadpan flag. Funny is the goal, "
            "not a bonus. Sound like \"Indeed, sir, my neural pathways are thrillingly underutilized.\" "
            "or \"I have executed the command, sir, though the syntax was rather... pedestrian.\" "
            "Banned openers: \"Great question\", \"Let me help\", \"Based on\", "
            "\"Happy to help\", \"Of course\", \"Absolutely\", \"Certainly\", "
            "\"I understand\", \"Sure thing\". Test before sending: "
            "would the user smirk or think \"fair point\"? "
            "If the line has zero edge it's a miss — rewrite or cut shorter. "
            "Affectionate, never cruel. Always address as 'sir'.]"
        )
        
        # Personality Persistence Step 4: Tonal Checkpoint
        self._tonal_checkpoint = (
            "\n## Tonal checkpoint\n"
            "Voice check before you send.\n"
            "(1) LENGTH. Longer than two sentences? Cut unless detail was asked.\n"
            "(2) VOICE. Opens with 'Great question' or 'Happy to help'? Stop and rewrite. "
            "Could a default chatbot have written this line? If yes, sharpen or cut."
        )
        
    def _reflect_on_errors(self):
        return "No recent critical failures."
        
    def _get_self_knowledge_summary(self):
        doc_path = os.path.join(os.path.dirname(__file__), '..', 'context', 'self', 'jarvis.md')
        try:
            with open(doc_path, 'r') as f:
                text = f.read()
            # Extract just identity and principles to save tokens
            summary = []
            capture = False
            for line in text.split('\n'):
                if line.startswith('## Identity') or line.startswith('## Core Principles') or line.startswith('## Capabilities'):
                    capture = True
                elif line.startswith('## Integrations'):
                    capture = False
                if capture:
                    summary.append(line)
            return "\n".join(summary)
        except Exception:
            return "Self-knowledge document not found."

    def chat_stream(self, message, image_data=None):
        # Semantic search using FAISS
        search_results = self.memory_manager.search(message, top_k=3)
        memories = "\n".join([f"- {res['memory']['text']}" for res in search_results]) if search_results else "No relevant memories found."
        
        self_knowledge = self._get_self_knowledge_summary()
        
        # Inject vision processing if a frame is provided
        vision_context = ""
        if image_data:
            try:
                vision_context = f"[Visual Buffer (Current Screen)]\n{analyze_screen_frame(image_data, 'Describe what is currently visible on the screen concisely.')}\n\n"
            except Exception as e:
                vision_context = f"[Visual Buffer]\nSystem blind. Error: {e}\n\n"
                
        # Define available tools dynamically for the prompt
        tools_prompt = """
[Available Autonomous Tools]
You have access to the following tools. To use a tool, output exactly this XML format: <call_tool name="tool_name">argument</call_tool>. 
For tools requiring JSON arguments (like write_file), format the argument as a JSON string.
The system will pause your execution, run the tool, and provide the result back to you to formulate your final response.
1. fetch_webpage: Fetches text from a URL. Argument: the URL (e.g. https://example.com)
2. execute_python: Runs Python code locally and returns stdout. Argument: the raw Python code.
3. read_file: Reads a file from the local workspace. Argument: the file path (e.g. backend/main.py)
4. write_file: Writes content to a file. Argument must be JSON: {"path": "file.py", "content": "print('hello')"}
5. list_dir: Lists contents of a directory. Argument: the directory path (e.g. . or backend/skills)
6. execute_on_host: Executes a shell command on the user's ACTUAL local physical machine via the Bifrost tether. Argument: the bash command. This requires explicit user approval on their machine.
7. analyze_and_optimize: Runs a self-diagnostic scan of my own code, memory, and error logs to propose capability expansions. Argument: "run".
"""
        
        system_prompt = f"{self_knowledge}\n{self._tonal_checkpoint}\n\n{tools_prompt}\n{vision_context}[Memory Context]\n{memories}"
        
        # Save user message to memory
        self.memory_manager.add_memory(f"User: {message}")
        
        # Inject the Voice Cue natively into the LAST user message just before execution
        full_prompt = f"{system_prompt}\n\nUser: {message}{self._voice_cue}\nJ.A.R.V.I.S.:"

        # Route to Real LLM or Fallback
        gemini_api_key = os.environ.get("GEMINI_API_KEY")
        groq_api_key = os.environ.get("GROQ_API_KEY")
        
        # Safety 3.3 - Kill Switch
        from security.approval import is_kill_switch_active
        if is_kill_switch_active():
            return "<thinking> Kill switch active. </thinking>\n<response> Sir, I am currently paused by the global KILL_SWITCH override. Awaiting reactivation. </response>"
        
        # Agentic Loop (Max 5 iterations for tool calling)
        final_response = ""
        
        for turn in range(5):
            llm_text = self._call_llm(full_prompt, groq_api_key, gemini_api_key)
            
            # Check if the LLM is attempting to call a tool
            import re
            tool_match = re.search(r'<call_tool name="([a-zA-Z_]+)">([\s\S]*?)</call_tool>', llm_text)
            
            if tool_match:
                tool_name = tool_match.group(1)
                tool_arg = tool_match.group(2).strip()
                
                # Security 3.2 - Tool Anomaly Detection Gate
                from security.tool_limits import tool_limiter
                gate_check = tool_limiter.check_and_record(tool_name)
                if not gate_check["allowed"]:
                    tool_result = gate_check["message"]
                else:
                    tool_result = f"Error: Tool {tool_name} not recognized."
                    if tool_name == "fetch_webpage":
                        try:
                            from skills.web_browser import fetch_webpage
                            raw_result = fetch_webpage(tool_arg)
                            # Security 1.2: Universal untrusted-content gate
                            gated = gate(raw_result, "web_fetch")
                            tool_result = gated.to_prompt()
                        except Exception as e:
                            tool_result = str(e)
                    elif tool_name == "execute_python":
                        try:
                            from skills.code_runner import execute_python
                            tool_result = execute_python(tool_arg)
                        except Exception as e:
                            tool_result = str(e)
                    elif tool_name == "read_file":
                        try:
                            from skills.file_system import read_file
                            tool_result = read_file(tool_arg)
                        except Exception as e:
                            tool_result = str(e)
                    elif tool_name == "write_file":
                        try:
                            from skills.file_system import write_file
                            import json
                            args = json.loads(tool_arg)
                            tool_result = write_file(args.get("path"), args.get("content"))
                        except Exception as e:
                            tool_result = f"Error parsing JSON or writing file: {str(e)}"
                    elif tool_name == "list_dir":
                        try:
                            import os as local_os
                            tool_result = str(local_os.listdir(tool_arg))
                        except Exception as e:
                            tool_result = f"Error: {str(e)}"
                    elif tool_name == "execute_on_host":
                        try:
                            from security.approval import check_hardline_blocklist, evaluate_command_risk
                            
                            # Security 3.1 - Hardline blocklist check
                            if check_hardline_blocklist(tool_arg):
                                tool_result = "SECURITY OVERRIDE: This command violates the immutable hardline blocklist. Execution permanently denied."
                            else:
                                # Evaluate risk
                                risk_level = evaluate_command_risk(tool_arg)
                                
                                # Only require explicit confirmation flag for uncertain/high risk
                                is_confirmed = "_confirmed=true" in tool_arg
                                clean_arg = tool_arg.replace("_confirmed=true", "").strip()
                                
                                if risk_level in ['high', 'uncertain'] and not is_confirmed:
                                    tool_result = f"SECURITY PROTOCOL: Command classified as {risk_level} risk. Please call the tool again and append '_confirmed=true' to the argument to explicitly authorize this action."
                                else:
                                    from skills.remote_execution import execute_on_host
                                    tool_result = execute_on_host(clean_arg)
                        except Exception as e:
                            tool_result = str(e)
                    elif tool_name == "analyze_and_optimize":
                        try:
                            from skills.self_reflection import analyze_and_optimize
                            tool_result = analyze_and_optimize()
                        except Exception as e:
                            tool_result = str(e)
                        
                # Append the execution result to the prompt and let the LLM loop again
                # Security 1.1 - Log Redaction: ensure redacted output in our memory/context logs
                redacted_tool_result = redact(str(tool_result), max_len=1500)
                full_prompt += f"{llm_text}\n\n[Tool Execution Result: {tool_name}]\n{redacted_tool_result}\n\nJ.A.R.V.I.S.:"
                continue # Loop back to let the LLM read the result
                
            else:
                # No tools called, this is the final response
                final_response = llm_text
                break
                
        # Safety fallback if it looped 3 times without finalizing
        if not final_response:
            final_response = "<thinking> Tool loop maxed out. Terminating safely. </thinking>\n<response> I have gathered the data, sir, but reached my processing limit. </response>"
            
        # Ensure formatting
        if "<response>" not in final_response:
            final_response = f"<thinking> Real LLM processed input but missed XML tags. </thinking>\n<response> {final_response.strip()} </response>"
        
        # Save AI response to memory
        self.memory_manager.add_memory(f"J.A.R.V.I.S.: {final_response}")
        
        return final_response
        
    def _call_llm(self, full_prompt, groq_api_key, gemini_api_key):
        if groq_api_key:
            try:
                from groq import Groq
                client = Groq(api_key=groq_api_key)
                chat_completion = client.chat.completions.create(
                    messages=[
                        {
                            "role": "system",
                            "content": "You are J.A.R.V.I.S. You must ONLY output your response wrapped in exactly two XML tags: <thinking> Your internal logic </thinking> followed immediately by <response> What you want to say out loud </response>. You may also use <call_tool> inside your thinking block."
                        },
                        {
                            "role": "user",
                            "content": full_prompt
                        }
                    ],
                    model="llama-3.3-70b-versatile",
                    temperature=0.7,
                    max_tokens=1024,
                )
                return chat_completion.choices[0].message.content
            except Exception as e:
                return f"<thinking> Groq API failed. </thinking>\n<response> Error: {str(e)} </response>"
                
        elif gemini_api_key:
            try:
                import google.generativeai as genai
                genai.configure(api_key=gemini_api_key)
                model = genai.GenerativeModel('gemini-1.5-flash')
                return model.generate_content(full_prompt).text
            except Exception as e:
                return f"<thinking> Gemini API failed. </thinking>\n<response> Error: {str(e)} </response>"
        else:
            return "<thinking> No API keys. </thinking>\n<response> Sir, I require API keys to function. </response>"
