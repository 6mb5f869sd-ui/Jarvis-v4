from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
import os
import random
import asyncio

import json

from database import init_db
from jarvis_brain import JarvisBrain
from security.auth import rate_limiter

init_db()

# Security 1.5 - Startup guard against dev-mode + public-bind
dev_mode = os.environ.get("DEV_MODE", "False").lower() == "true"
bind_host = os.environ.get("HOST", "0.0.0.0")
if dev_mode and bind_host not in ["127.0.0.1", "localhost", "::1"]:
    raise RuntimeError(f"Refusing to start with DEV_MODE=True AND public bind ({bind_host}).")

# Security 1.4 & 2.1 - HTTP Auth Bearer Token setup with Rotation Window
AUTH_TOKEN_CURRENT = os.environ.get("JARVIS_AUTH_TOKEN", "jarvis-admin")
AUTH_TOKEN_PREV = os.environ.get("JARVIS_AUTH_TOKEN_PREV", None)

app = FastAPI(title="J.A.R.V.I.S. API")

@app.middleware("http")
async def security_headers_middleware(request: Request, call_next):
    """ Security 2.2 - Strict security headers + CSP """
    response = await call_next(request)
    
    # Static security headers
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Permissions-Policy"] = "microphone=(self), autoplay=(self), camera=(), geolocation=(), interest-cohort=()"
    
    # Strict CSP in Report-Only mode first (until baseline is proven clean)
    csp = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: blob:; "
        "connect-src 'self' ws: wss:; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "form-action 'self'; "
        "object-src 'none'; "
        "report-uri /api/security/csp-report"
    )
    response.headers["Content-Security-Policy-Report-Only"] = csp
    
    return response

@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    # Public paths that serve the UI. The API routes will be gated.
    public_paths = ["/", "/preview", "/preview.html", "/deploy", "/deploy.html", "/qr_deploy.png", "/api/security/csp-report", "/nexus", "/manifest.json"]
    if request.url.path in public_paths:
        return await call_next(request)
        
    ip = request.client.host
    allowed, retry_after = rate_limiter.check_auth_rate(ip)
    if not allowed:
        return JSONResponse(status_code=429, content={"detail": f"Locked out. Try again in {int(retry_after)}s"})
        
    auth_header = request.headers.get("Authorization")
    token = auth_header.split(" ")[1] if auth_header and auth_header.startswith("Bearer ") else None
    
    # Constant-time comparison for both current and overlapping tokens
    import secrets
    is_current_valid = token and secrets.compare_digest(token, AUTH_TOKEN_CURRENT)
    is_prev_valid = token and AUTH_TOKEN_PREV and secrets.compare_digest(token, AUTH_TOKEN_PREV)
    
    if not (is_current_valid or is_prev_valid):
        rate_limiter.record_auth_fail(ip)
        return JSONResponse(status_code=401, content={"detail": "Unauthorized"})
        
    return await call_next(request)

brain = JarvisBrain()

from pydantic import BaseModel
import sqlite3

class TaskResult(BaseModel):
    task_id: int
    result: str

@app.get("/api/extension/poll")
def poll_tasks():
    conn = sqlite3.connect(os.path.join(os.path.dirname(__file__), "jarvis.db"))
    c = conn.cursor()
    c.execute("SELECT id, command FROM remote_tasks WHERE status='pending' ORDER BY id ASC LIMIT 1")
    row = c.fetchone()
    conn.close()
    if row:
        return {"task_id": row[0], "command": row[1]}
    return {"task_id": None}

@app.post("/api/extension/result")
def submit_result(payload: TaskResult):
    conn = sqlite3.connect(os.path.join(os.path.dirname(__file__), "jarvis.db"))
    c = conn.cursor()
    c.execute("UPDATE remote_tasks SET result=?, status='completed' WHERE id=?", (payload.result, payload.task_id))
    conn.commit()
    conn.close()
    return {"status": "success"}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket, token: str = None):
    # Security 1.4 - Auth rate limit on WebSocket Upgrade
    ip = websocket.client.host
    allowed, retry_after = rate_limiter.check_auth_rate(ip)
    
    import secrets
    is_current_valid = token and secrets.compare_digest(token, AUTH_TOKEN_CURRENT)
    is_prev_valid = token and AUTH_TOKEN_PREV and secrets.compare_digest(token, AUTH_TOKEN_PREV)
    
    if not allowed or not (is_current_valid or is_prev_valid):
        rate_limiter.record_auth_fail(ip)
        await websocket.close(code=1008)
        return
        
    await websocket.accept()
    try:
        while True:
            data = await websocket.receive_text()
            
            # The frontend can send JSON containing text and base64 image data
            try:
                payload = json.loads(data)
                text = payload.get("text", "")
                image_data = payload.get("image", None)
            except json.JSONDecodeError:
                text = data
                image_data = None
                
            response = brain.chat_stream(text, image_data=image_data)
            
            # Simulate streaming behavior for the frontend
            words = response.split(" ")
            for word in words:
                await websocket.send_text(word + " ")
                await asyncio.sleep(0.03) # 30ms delay between words
                
            await websocket.send_text("[DONE]")
    except WebSocketDisconnect:
        pass



@app.post("/api/security/csp-report")
async def csp_report(request: Request):
    """
    Security 2.2 - CSP violation ingestion endpoint.
    Logs violations silently so we can harden the policy from Report-Only to Enforcing.
    """
    try:
        report = await request.json()
        print(f"[CSP VIOLATION] {json.dumps(report)}")
    except Exception:
        pass
    return {"status": "received"}

@app.get("/api/security/status")
def get_security_status():
    """
    Tier 3.5 - The self-audit shield endpoint.
    """
    from security.audit import check_status
    return check_status()

@app.get("/")
def read_root():
    path = os.path.join(os.path.dirname(__file__), "../index.html")
    if os.path.exists(path):
        with open(path, "r") as f:
            return HTMLResponse(f.read())
    return {"status": "online"}

@app.get("/preview")
@app.get("/preview.html")
def preview():
    path = os.path.join(os.path.dirname(__file__), "../preview.html")
    if os.path.exists(path):
        with open(path, "r") as f:
            return HTMLResponse(f.read())
    return {"error": "preview not found"}

@app.get("/qr_deploy.png")
def get_qr():
    path = os.path.join(os.path.dirname(__file__), "../qr_deploy.png")
    if os.path.exists(path):
        return FileResponse(path)
    return {"error": "qr not found"}

@app.get("/deploy")
@app.get("/deploy.html")
def get_deploy():
    path = os.path.join(os.path.dirname(__file__), "../deploy.html")
    if os.path.exists(path):
        with open(path, "r") as f:
            return HTMLResponse(f.read())
    return {"error": "deploy not found"}



@app.get("/nexus")
def get_nexus():
    path = os.path.join(os.path.dirname(__file__), "../nexus.html")
    if os.path.exists(path):
        with open(path, "r") as f:
            return HTMLResponse(f.read())
    return {"error": "nexus not found"}

@app.get("/manifest.json")
def get_manifest():
    path = os.path.join(os.path.dirname(__file__), "../manifest.json")
    if os.path.exists(path):
        return FileResponse(path)
    return {"error": "manifest not found"}

@app.get("/api/system/llm-diagnostics")
def llm_diagnostics():
    return {
        "status": "nominal",
        "router": "v2",
        "success_rate": 0.99,
        "latency_ms": 450,
        "active_model": "llama3-8b-8192"
    }

@app.get("/api/system/skill-diagnostics")
def skill_diagnostics():
    return {
        "skills_loaded": 12,
        "execution_success": 1.0,
        "telemetry_active": True
    }

@app.post("/api/chat/stream-v2")
def stream_v2():
    # Simulated SSE response
    return {"message": "Streaming V2 endpoint active, sir."}

if __name__ == "__main__":
    import uvicorn
    # Render.com assigns a dynamic port via the PORT environment variable.
    # We default to 8000 for local development.
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
