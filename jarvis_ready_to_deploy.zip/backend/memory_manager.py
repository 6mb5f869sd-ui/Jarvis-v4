import sqlite3
import numpy as np
import faiss
import json
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "jarvis.db")

class MemoryManager:
    def __init__(self):
        # We will use a lightweight term frequency approach for embedding strings
        # because the environment space maxed out when trying to download `sentence-transformers`.
        # However, FAISS still gives us lightning-fast nearest-neighbor similarity.
        self.dimension = 128
        self.index = faiss.IndexFlatL2(self.dimension)
        self.memories = []
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS semantic_memory
                     (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT, metadata TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)''')
        conn.commit()
        
        c.execute('SELECT id, text, metadata FROM semantic_memory')
        rows = c.fetchall()
        for row in rows:
            self._load_memory(row[0], row[1], json.loads(row[2]))
        conn.close()

    def _pseudo_embed(self, text):
        """
        Creates a lightweight pseudo-embedding using a hash hashing trick since 
        transformers exceeded the disk space limit. 
        """
        words = text.lower().split()
        vector = np.zeros(self.dimension, dtype=np.float32)
        for w in words:
            # Simple hashing trick
            idx = hash(w) % self.dimension
            vector[idx] += 1.0
        # Normalize
        norm = np.linalg.norm(vector)
        if norm > 0:
            vector = vector / norm
        return vector

    def _load_memory(self, mem_id, text, metadata):
        vector = self._pseudo_embed(text)
        self.index.add(np.array([vector]))
        self.memories.append({"id": mem_id, "text": text, "metadata": metadata})

    def add_memory(self, text, metadata=None):
        if metadata is None:
            metadata = {}
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("INSERT INTO semantic_memory (text, metadata) VALUES (?, ?)", (text, json.dumps(metadata)))
        mem_id = c.lastrowid
        conn.commit()
        conn.close()
        
        self._load_memory(mem_id, text, metadata)
        return mem_id

    def search(self, query, top_k=3):
        if len(self.memories) == 0:
            return []
            
        vector = self._pseudo_embed(query)
        distances, indices = self.index.search(np.array([vector]), top_k)
        
        results = []
        for i, idx in enumerate(indices[0]):
            if idx != -1 and idx < len(self.memories):
                results.append({
                    "distance": distances[0][i],
                    "memory": self.memories[idx]
                })
        return results

if __name__ == "__main__":
    mm = MemoryManager()
    mm.add_memory("Sir requested that I never use emojis and address him formally.")
    mm.add_memory("The system was rebuilt with a self-knowledge document.")
    print(mm.search("Do you use emojis?", top_k=1))
