import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "jarvis.db")

def migrate_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS remote_tasks
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, command TEXT, result TEXT, status TEXT DEFAULT 'pending', created_at DATETIME DEFAULT CURRENT_TIMESTAMP)''')
    conn.commit()
    conn.close()
    print("Database migrated with remote_tasks table.")

if __name__ == "__main__":
    migrate_db()