import os
import re

def is_kill_switch_active() -> bool:
    val = os.environ.get("JARVIS_KILL_SWITCH", "false").lower()
    return val in ["true", "1", "yes", "on"]

def check_hardline_blocklist(command: str) -> bool:
    """
    Immutable blocklist that absolutely prevents catastrophic shell commands.
    Returns True if the command is blocked.
    """
    # Normalize command to prevent simple bypasses
    norm = command.lower().strip()
    
    blocked_patterns = [
        r'rm\s+-r[fF]?\s+/',           # rm -rf /
        r':\(\)\{\s*:\|:&?\s*\};\s*:', # fork bomb
        r'dd\s+if=.*of=/dev/(sd|disk|nvme|hd|xvd)', # disk wipe
        r'mkfs.*/dev/',               # format disk
        r'>\s*/dev/(sd|disk|nvme|hd|xvd)', # overwrite disk
        r'shred\s+/',                 # shred root
        r'chmod\s+-R\s+777\s+/',      # open root permissions
        r'(curl|wget).*\|\s*(bash|sh)' # pipe to shell
    ]
    
    for pattern in blocked_patterns:
        if re.search(pattern, norm):
            return True
    return False

def evaluate_command_risk(command: str) -> str:
    """
    Evaluates the risk of a command. 
    Returns: 'low', 'uncertain', or 'high'.
    """
    norm = command.lower()
    
    high_risk = [
        r'rm\s+-r[fF]?',
        r'drop\s+(table|database|schema)',
        r'delete\s+from\s+[^\s]+\s*$', # delete without WHERE
        r'git\s+push\s+--force',
        r'git\s+reset\s+--hard',
        r'format\s+'
    ]
    
    uncertain_risk = [
        r'\.env',
        r'sudo\s+',
        r'kill\s+-9',
        r'npm\s+publish',
        r'docker\s+rm\s+-f'
    ]
    
    for pattern in high_risk:
        if re.search(pattern, norm):
            return 'high'
            
    for pattern in uncertain_risk:
        if re.search(pattern, norm):
            return 'uncertain'
            
    return 'low'
