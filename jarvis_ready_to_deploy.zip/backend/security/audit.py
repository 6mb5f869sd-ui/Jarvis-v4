import os

def check_status() -> dict:
    """
    Tier 3.5 - The self-audit + UI security shield
    Gathers security telemetry to feed the frontend shield.
    """
    score = 100
    signals = []
    
    # 1. Kill Switch
    from security.approval import is_kill_switch_active
    if is_kill_switch_active():
        score -= 100
        signals.append({"name": "kill-switch", "status": "critical", "detail": "ACTIVE: Agent Paused"})
    else:
        signals.append({"name": "kill-switch", "status": "ok", "detail": "off"})
        
    # 2. API Keys
    if not os.environ.get("GROQ_API_KEY") and not os.environ.get("GEMINI_API_KEY"):
        score -= 50
        signals.append({"name": "llm-api-key", "status": "critical", "detail": "unset"})
    else:
        signals.append({"name": "llm-api-key", "status": "ok", "detail": "set"})
        
    # 3. Auth Token
    if os.environ.get("JARVIS_AUTH_TOKEN") == "jarvis-admin":
        score -= 10
        signals.append({"name": "bearer-token", "status": "warning", "detail": "using default token"})
    else:
        signals.append({"name": "bearer-token", "status": "ok", "detail": "set"})
        
    # 4. Dev Mode Bind
    dev_mode = os.environ.get("DEV_MODE", "False").lower() == "true"
    bind_host = os.environ.get("HOST", "0.0.0.0")
    if dev_mode and bind_host != "127.0.0.1":
        score -= 40
        signals.append({"name": "dev-mode-bind", "status": "critical", "detail": "DANGEROUS: public bind"})
    else:
        signals.append({"name": "dev-mode-bind", "status": "ok", "detail": "off"})
        
    # Clamp score
    score = max(0, min(100, score))
    
    color = "green"
    if score < 85: color = "amber"
    if score < 60: color = "red"
    
    return {
        "score": score,
        "color": color,
        "signals": signals
    }
