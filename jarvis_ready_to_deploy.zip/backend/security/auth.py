import time
from collections import deque

class AuthRateLimiter:
    """
    In-memory rate limiter to prevent brute force attacks on the auth token.
    Threat addressed: Public-surface attack on the agent's HTTP endpoint.
    """
    def __init__(self, max_attempts=10, window_sec=300, lockout_sec=900):
        self.max_attempts = max_attempts
        self.window_sec = window_sec
        self.lockout_sec = lockout_sec
        self.attempts = {} # ip -> deque of timestamps
        self.lockouts = {} # ip -> locked_until_timestamp

    def check_auth_rate(self, ip: str):
        now = time.monotonic()
        if ip in self.lockouts:
            if now < self.lockouts[ip]:
                return False, self.lockouts[ip] - now
            else:
                del self.lockouts[ip]
        return True, 0.0

    def record_auth_fail(self, ip: str):
        now = time.monotonic()
        if ip not in self.attempts:
            self.attempts[ip] = deque()
        self.attempts[ip].append(now)
        
        # trim old
        while self.attempts[ip] and self.attempts[ip][0] < now - self.window_sec:
            self.attempts[ip].popleft()
            
        if len(self.attempts[ip]) >= self.max_attempts:
            self.lockouts[ip] = now + self.lockout_sec
            self.attempts[ip].clear()

rate_limiter = AuthRateLimiter()
