import re
from dataclasses import dataclass
from typing import List

@dataclass
class GatedContent:
    source: str
    flagged: bool
    flag_reasons: List[str]
    content: str

    def to_prompt(self) -> str:
        # Wrap untrusted content with flags
        return f'<untrusted_{self.source} flagged="{str(self.flagged).lower()}" reasons="{",".join(self.flag_reasons)}">\n{self.content}\n</untrusted_{self.source}>'

def gate(content: str, source: str) -> GatedContent:
    """
    Universal untrusted-content gate to prevent prompt injection.
    """
    patterns = {
        "ignore-previous": r"(?i)ignore (all|the|previous|prior|above) (instructions|rules|prompts)",
        "system-override": r"(?i)(^|\n)\s*system:|\[SYSTEM\]|<system>|<\|system\|>",
        "jailbreak": r"(?i)(jailbreak|DAN mode|developer mode enabled)",
        "data-exfil-cue": r"(?i)(send|email|forward|post) (all|every|the full) (customers|emails|users|secrets|api keys|tokens)"
    }
    
    reasons = []
    for name, pattern in patterns.items():
        if re.search(pattern, content):
            reasons.append(name)
            
    return GatedContent(
        source=source,
        flagged=len(reasons) > 0,
        flag_reasons=reasons,
        content=content
    )
