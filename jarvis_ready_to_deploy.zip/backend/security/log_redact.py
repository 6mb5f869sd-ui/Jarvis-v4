import re

def redact(text: str, max_len: int = 500) -> str:
    """
    Redacts sensitive API keys and tokens from a string.
    """
    if not isinstance(text, str):
        text = str(text)
        
    patterns = [
        # Groq
        (r'(?i)(gsk_[a-zA-Z0-9]{20,})', 'gsk_<REDACTED>'),
        # Gemini
        (r'(?i)(AIzaSy[a-zA-Z0-9_-]{30,})', 'AIzaSy<REDACTED>'),
        # OpenAI/Anthropic/generic sk-
        (r'(?i)(sk-[a-zA-Z0-9]{20,})', 'sk-<REDACTED>'),
        # Bearer tokens
        (r'(?i)(bearer\s+[a-zA-Z0-9_\-\.]+)', 'Bearer <REDACTED>')
    ]
    
    redacted_text = text
    for pattern, replacement in patterns:
        redacted_text = re.sub(pattern, replacement, redacted_text)
        
    if len(redacted_text) > max_len:
        redacted_text = redacted_text[:max_len] + "... [TRUNCATED]"
        
    return redacted_text
