import os

def shell_minimal() -> dict:
    """
    Returns an environment dictionary containing only safe baseline OS variables.
    Threat addressed: Account/key compromise via subprocess environment inheritance.
    """
    allowed = {'HOME', 'PATH', 'USER', 'LANG', 'LC_ALL', 'TMPDIR', 'SHELL', 'PWD', 'DISPLAY'}
    return {k: v for k, v in os.environ.items() if k in allowed}

def with_keys(*keys) -> dict:
    """
    Returns shell_minimal plus specifically requested keys.
    """
    env = shell_minimal()
    for k in keys:
        if k in os.environ:
            env[k] = os.environ[k]
    return env

def full(reason: str) -> dict:
    """
    Inherits the full environment. Requires a justification string.
    """
    if not reason:
        raise ValueError("Must provide a reason to inherit the full environment to prevent secret leaks.")
    return dict(os.environ)
