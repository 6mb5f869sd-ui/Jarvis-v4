import time

class ToolRateLimiter:
    """
    Tier 3.2 - Per-tool anomaly detection (sliding-window safety caps)
    Prevents runaway agent loops from destroying quotas or filesystems.
    """
    def __init__(self):
        # Maps tool_name -> [(timestamp1), (timestamp2), ...]
        self.history = {}
        
        # Define limits: (max_calls, window_in_seconds)
        self.limits = {
            "execute_python": (20, 3600),   # 20 per hour
            "execute_on_host": (10, 3600),  # 10 per hour
            "write_file": (30, 3600),       # 30 per hour
            "fetch_webpage": (50, 3600),    # 50 per hour
            "read_file": (100, 3600),       # 100 per hour
            "list_dir": (100, 3600),        # 100 per hour
            "analyze_and_optimize": (5, 3600) # 5 per hour
        }

    def check_and_record(self, tool_name: str) -> dict:
        """
        Returns {"allowed": True} if within limits.
        Returns {"allowed": False, "message": "..."} if blocked.
        """
        if tool_name not in self.limits:
            return {"allowed": True} # Uncapped tool
            
        max_calls, window = self.limits[tool_name]
        now = time.monotonic()
        
        if tool_name not in self.history:
            self.history[tool_name] = []
            
        # Clean old history
        self.history[tool_name] = [t for t in self.history[tool_name] if t > now - window]
        
        if len(self.history[tool_name]) >= max_calls:
            return {
                "allowed": False, 
                "message": f"anomaly_gate_blocked: Tool '{tool_name}' exceeded safety cap of {max_calls} calls per {window} seconds."
            }
            
        # Record successful grant
        self.history[tool_name].append(now)
        return {"allowed": True}

tool_limiter = ToolRateLimiter()
