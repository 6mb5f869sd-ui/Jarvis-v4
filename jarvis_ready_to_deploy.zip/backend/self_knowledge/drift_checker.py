import os
import sys

def check_drift(doc_path: str):
    with open(doc_path, 'r') as f:
        text = f.read()

    findings = []
    
    # We will statically check if file paths mentioned in the text actually exist.
    # Look for paths surrounded by backticks (common markdown for code/paths).
    import re
    # Match strings ending in .py, .html, .js within backticks
    paths = re.findall(r'`([a-zA-Z0-9_/\-]+\.(?:py|html|js))`', text)
    
    repo_root = os.path.join(os.path.dirname(__file__), '..', '..')
    
    for path in set(paths):
        # Resolve path against repo root
        full_path = os.path.join(repo_root, path)
        if not os.path.exists(full_path):
            findings.append({
                "kind": "missing_file",
                "reference": path,
                "reason": f"File '{path}' referenced in doc does not exist on disk."
            })
            
    return findings

if __name__ == "__main__":
    doc_path = os.path.join(os.path.dirname(__file__), '..', '..', 'context', 'self', 'jarvis.md')
    is_strict = '--strict' in sys.argv
    
    findings = check_drift(doc_path)
    
    if not findings:
        print("Drift check passed.")
        sys.exit(0)
    else:
        for f in findings:
            print(f"WARN: {f['reason']}")
        if is_strict:
            sys.exit(1)
        sys.exit(0)
