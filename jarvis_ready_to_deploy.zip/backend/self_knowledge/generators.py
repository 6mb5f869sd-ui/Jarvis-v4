import os
import subprocess
import sys
import os

# Append backend directory so we can load the security module
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

try:
    from security.subprocess_env import shell_minimal
except ImportError:
    def shell_minimal(): return dict(os.environ)

# Try to import the parser from the same directory
try:
    from .parser import parse_blocks, serialize_blocks
except ImportError:
    # Fallback for direct script execution
    from parser import parse_blocks, serialize_blocks

def generate_capabilities():
    """
    Introspects the actual registration site (backend/skills).
    Since this is a lightweight representation for now, we scan the skills dir.
    """
    skills_dir = os.path.join(os.path.dirname(__file__), '..', 'skills')
    if not os.path.exists(skills_dir):
        return "_unavailable, regenerate manually_\n"
        
    modules = [f[:-3] for f in os.listdir(skills_dir) if f.endswith('.py') and not f.startswith('__')]
    
    out = "| Module | Status |\n|--------|--------|\n"
    for mod in sorted(modules):
        out += f"| `{mod}` | Active |\n"
    return out + "\n"

def generate_integrations():
    """Stub generator for integrations."""
    out = "- Stripe: Simulated via OAuth config.\n"
    out += "- GitHub: Awaiting Token.\n"
    out += "- Google Calendar: Awaiting OAuth.\n"
    return out

def generate_voice_loop():
    """Generator for voice loop logic."""
    out = "Real-time loop utilizing Deepgram STT (via websocket) and ElevenLabs/Browser TTS.\n"
    out += "Note: Fallback to free browser TTS currently active.\n"
    return out

def generate_recent_activity():
    """Reads the last 5 commits from git log."""
    repo_dir = os.path.join(os.path.dirname(__file__), '..', '..')
    try:
        result = subprocess.run(
            ['git', 'log', '-n', '5', '--oneline'],
            cwd=repo_dir, capture_output=True, text=True, check=True,
            env=shell_minimal() # Tier 1.3 Subprocess Env Stripping
        )
        if result.stdout.strip():
            out = ""
            for line in result.stdout.strip().split('\n'):
                out += f"- `{line}`\n"
            return out + "\n"
        else:
            return "_No recent commits found._\n"
    except Exception:
        return "_git log unavailable_\n"

def generate_all(doc_path):
    with open(doc_path, 'r') as f:
        text = f.read()
        
    parts = parse_blocks(text)
    
    generators = {
        'capabilities': generate_capabilities,
        'integrations': generate_integrations,
        'voice_loop': generate_voice_loop,
        'recent_activity': generate_recent_activity
    }
    
    changed = False
    for p in parts:
        if p['type'] == 'auto':
            name = p['name']
            if name in generators:
                new_content = generators[name]()
                if p['content'] != new_content:
                    p['content'] = new_content
                    changed = True
                    
    if changed:
        new_text = serialize_blocks(parts)
        with open(doc_path, 'w') as f:
            f.write(new_text)
        return True
    return False

if __name__ == "__main__":
    doc_path = os.path.join(os.path.dirname(__file__), '..', '..', 'context', 'self', 'jarvis.md')
    if generate_all(doc_path):
        print("Updated doc.")
    else:
        print("No changes.")
