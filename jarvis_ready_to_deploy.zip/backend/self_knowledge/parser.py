import re
import os

def parse_blocks(doc_text: str):
    """
    Reads markdown and separates hand-written content from AUTO blocks.
    Returns a list of dicts: {'type': 'text'|'auto', 'name': str|None, 'content': str}
    """
    pattern = re.compile(
        r'(<!-- AUTO-START: (.*?) -->\n)(.*?)(<!-- AUTO-END: \2 -->)',
        re.DOTALL
    )
    
    parts = []
    last_end = 0
    
    for match in pattern.finditer(doc_text):
        start = match.start()
        
        # Add preceding text
        if start > last_end:
            parts.append({
                'type': 'text',
                'name': None,
                'content': doc_text[last_end:start]
            })
            
        parts.append({
            'type': 'auto',
            'name': match.group(2),
            'content': match.group(3),
            'start_marker': match.group(1),
            'end_marker': match.group(4)
        })
        
        last_end = match.end()
        
    # Add trailing text
    if last_end < len(doc_text):
        parts.append({
            'type': 'text',
            'name': None,
            'content': doc_text[last_end:]
        })
        
    return parts

def serialize_blocks(parts: list) -> str:
    """Reassembles the document from parts."""
    out = []
    for p in parts:
        if p['type'] == 'text':
            out.append(p['content'])
        elif p['type'] == 'auto':
            out.append(p['start_marker'])
            out.append(p['content'])
            out.append(p['end_marker'])
    return "".join(out)

def test_round_trip():
    sample = (
        "Hello\n<!-- AUTO-START: xyz -->\nold content\n<!-- AUTO-END: xyz -->\nWorld\n"
    )
    parts = parse_blocks(sample)
    assert len(parts) == 3
    assert parts[1]['name'] == 'xyz'
    assert serialize_blocks(parts) == sample
    print("Round-trip test passed.")

if __name__ == "__main__":
    test_round_trip()
