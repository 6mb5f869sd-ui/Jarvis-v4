import subprocess
import tempfile
import os
from security.subprocess_env import shell_minimal

def execute_python(code: str) -> str:
    """
    Executes Python code in a sandboxed temporary file.
    Returns the standard output and standard error.
    """
    try:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write(code)
            temp_path = f.name
        
        result = subprocess.run(
            ['python', temp_path], 
            capture_output=True, 
            text=True, 
            timeout=15, 
            env=shell_minimal() # Tier 1.3 Subprocess Env Stripping
        )
        os.unlink(temp_path)
        
        output = result.stdout
        if result.stderr:
            output += f"\nErrors:\n{result.stderr}"
            
        if not output.strip():
            return "Code executed successfully with no output."
            
        return output[:4000] # Cap output length
    except subprocess.TimeoutExpired:
        os.unlink(temp_path)
        return "Error: Code execution timed out after 15 seconds."
    except Exception as e:
        return f"Execution failed: {str(e)}"
