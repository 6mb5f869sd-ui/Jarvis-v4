import os

def read_file(path: str) -> str:
    """Reads the content of a file."""
    try:
        # Prevent absolute path escaping out of workspace for safety, though technically sandboxed
        safe_path = os.path.abspath(os.path.join(os.getcwd(), path))
        if not os.path.exists(safe_path):
            return f"Error: File '{path}' does not exist."
        with open(safe_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        return f"Error reading file: {str(e)}"

def write_file(path: str, content: str) -> str:
    """Writes content to a file, creating directories if necessary."""
    try:
        safe_path = os.path.abspath(os.path.join(os.getcwd(), path))
        os.makedirs(os.path.dirname(safe_path), exist_ok=True)
        with open(safe_path, 'w', encoding='utf-8') as f:
            f.write(content)
        return f"Successfully wrote to {path}"
    except Exception as e:
        return f"Error writing file: {str(e)}"

import os

def list_dir(path: str = ".") -> str:
    """Lists files and directories in the given path."""
    try:
        # Check if we're running from the root vs backend dir
        if not os.path.exists(path):
            # Try prepending backend if we are running from jarvis-assistant root and looking for skills directly
            if os.path.exists(os.path.join("backend", path)):
                path = os.path.join("backend", path)
            elif os.path.exists(os.path.join("..", path)):
                path = os.path.join("..", path)
        
        safe_path = os.path.abspath(os.path.join(os.getcwd(), path))
        if not os.path.exists(safe_path):
            return f"Error: Directory '{path}' does not exist (resolved to {safe_path})."
        items = os.listdir(safe_path)
        return "\n".join(items) if items else "Directory is empty."
    except Exception as e:
        return f"Error listing directory: {str(e)}"
