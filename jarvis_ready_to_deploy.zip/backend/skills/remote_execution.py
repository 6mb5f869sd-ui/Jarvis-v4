import sqlite3
import time
import os

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'jarvis.db')

def execute_on_host(command: str) -> str:
    """
    Sends a command to the remote user's physical host machine via the Bifrost tether.
    This entirely escapes the local Docker/Replit sandbox.
    """
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("INSERT INTO remote_tasks (command) VALUES (?)", (command,))
        task_id = c.lastrowid
        conn.commit()
        conn.close()

        # Poll for completion (timeout 20 seconds)
        for _ in range(20):
            time.sleep(1)
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("SELECT status, result FROM remote_tasks WHERE id=?", (task_id,))
            row = c.fetchone()
            conn.close()
            
            if row and row[0] == 'completed':
                return row[1][:4000] # Cap output
                
        # Timeout
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("UPDATE remote_tasks SET status='timeout' WHERE id=?", (task_id,))
        conn.commit()
        conn.close()
        return "Error: Remote execution timed out. Is the jarvis_node.py tether running on your host machine?"
    except Exception as e:
        return f"Database error in remote bridge: {str(e)}"