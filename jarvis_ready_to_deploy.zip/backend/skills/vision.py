import google.generativeai as genai
import os
import base64
from io import BytesIO

def analyze_screen_frame(base64_image_data: str, prompt: str) -> str:
    """
    Sends a base64 encoded screen frame to Gemini 1.5 Flash for rapid, free visual processing.
    """
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return "I am currently blind, sir. Please configure GEMINI_API_KEY to activate my visual cortex."
        
    genai.configure(api_key=api_key)
    
    # Initialize the fast, multimodal model
    model = genai.GenerativeModel('gemini-1.5-flash')
    
    # Decode the base64 string
    # Assuming the data is stripped of the 'data:image/jpeg;base64,' prefix
    try:
        if "," in base64_image_data:
            base64_image_data = base64_image_data.split(",")[1]
            
        img_data = base64.b64decode(base64_image_data)
        
        # Structure the payload for Gemini
        image_parts = [
            {
                "mime_type": "image/jpeg",
                "data": img_data
            }
        ]
        
        response = model.generate_content([prompt, image_parts[0]])
        return response.text
        
    except Exception as e:
        return f"Visual processing encountered an error: {str(e)}"
