from playwright.sync_api import sync_playwright

def fetch_webpage(url: str) -> str:
    """
    Autonomous Web Browsing Skill.
    Uses headless Chromium to navigate to a URL, wait for dynamic rendering,
    and extract the pure visible text content.
    """
    try:
        with sync_playwright() as p:
            # Launch headless chromium
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            
            # Navigate to the target URL
            page.goto(url, timeout=15000, wait_until="domcontentloaded")
            
            # Strip out scripts and styles before extracting text to keep it clean
            page.evaluate("document.querySelectorAll('script, style').forEach(el => el.remove())")
            
            # Extract inner text of the body
            content = page.locator("body").inner_text()
            
            browser.close()
            
            # Truncate to 4000 chars to avoid blowing up the context window
            return content[:4000]
    except Exception as e:
        return f"Navigation to {url} failed: {str(e)}"
