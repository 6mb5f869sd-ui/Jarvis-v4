import urllib.request
import json
import sqlite3
import os
import subprocess

def run_tests():
    print("--- Starting System Diagnostics ---")
    
    # 1. Test Database
    db_path = os.path.join(os.path.dirname(__file__), 'backend', 'jarvis.db')
    if os.path.exists(db_path):
        conn = sqlite3.connect(db_path)
        c = conn.cursor()
        c.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [row[0] for row in c.fetchall()]
        print(f"[OK] Database connected. Tables: {tables}")
        conn.close()
    else:
        print("[FAIL] Database not found.")
        
    # 2. Test Memory Manager
    try:
        from backend.memory_manager import MemoryManager
        mm = MemoryManager()
        res = mm.search("test", top_k=1)
        print(f"[OK] FAISS Memory Manager initialized. Search works. Memory count: {len(mm.memories)}")
    except Exception as e:
        print(f"[FAIL] Memory Manager error: {e}")

    # 3. Test HTTP Endpoints (assuming server is running or we can just test the module)
    # Since we can't guarantee background uvicorn is alive without locking, we'll skip live HTTP fetch 
    # and instead test the Router/Brain modules directly.
    try:
        from backend.jarvis_brain import JarvisBrain
        brain = JarvisBrain()
        out = brain.chat_stream("Diagnostic test.")
        if "<response>" in out:
            print("[OK] JarvisBrain ReAct loop generated valid XML structure.")
        else:
            print("[FAIL] JarvisBrain output malformed.")
    except Exception as e:
        print(f"[FAIL] JarvisBrain error: {e}")
        
    # 4. Test Self-Knowledge hook
    try:
        res = subprocess.run(["python", "backend/self_knowledge/drift_checker.py", "--strict"], capture_output=True, text=True)
        if res.returncode == 0:
            print("[OK] Self-knowledge drift checker passed.")
        else:
            print(f"[FAIL] Drift checker failed: {res.stdout}")
    except Exception as e:
        print(f"[FAIL] Drift checker execution error: {e}")

    print("--- System Diagnostics Complete ---")

if __name__ == "__main__":
    run_tests()
